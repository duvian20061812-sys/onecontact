<?php
// newsletter.php - Manejo de suscripciones al boletín

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Aquí puedes agregar lógica para guardar el email en una base de datos
        // Por ejemplo, conectar a la base de datos y insertar el email

        // Simulación de éxito
        echo json_encode(['success' => true, 'message' => '¡Gracias por suscribirte!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Email inválido.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}
?>
