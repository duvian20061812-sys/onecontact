<!-- FOOTER ESTILO APPLE / ONECONTACT -->
<footer class="footer-onecontact text-light py-5 mt-5">
  <div class="container">
    <div class="row gy-5 align-items-start justify-content-between">

      <!-- Columna: Marca -->
      <div class="col-md-4 text-center text-md-start">
        <h4 class="fw-bold mb-3 text-gradient">OneContact</h4>
        <p class="text-muted mb-4 fs-6">
          Conectamos tecnología, personas y emociones para crear experiencias inolvidables.
        </p>

        <!-- Redes sociales -->
        <div class="d-flex gap-3 justify-content-center justify-content-md-start">
          <a href="#" class="social-btn"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="social-btn"><i class="fab fa-twitter"></i></a>
          <a href="#" class="social-btn"><i class="fab fa-linkedin-in"></i></a>
          <a href="#" class="social-btn"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

      <!-- Columna: Navegación -->
      <div class="col-6 col-md-2">
        <h6 class="fw-semibold text-uppercase mb-3 small">Navegación</h6>
        <ul class="list-unstyled">
          <li><a href="inicio" class="footer-link">Inicio</a></li>
          <li><a href="#servicios" class="footer-link">Servicios</a></li>
          <li><a href="#equipo" class="footer-link">Equipo</a></li>
          <li><a href="ingreso" class="footer-link">Ingreso</a></li>
        </ul>
      </div>

      <!-- Columna: Empresa -->
      <div class="col-6 col-md-2">
        <h6 class="fw-semibold text-uppercase mb-3 small">Empresa</h6>
        <ul class="list-unstyled">
          <li><a href="#" class="footer-link">Nosotros</a></li>
          <li><a href="#" class="footer-link">Carreras</a></li>
          <li><a href="#" class="footer-link">Blog</a></li>
          <li><a href="#" class="footer-link">Prensa</a></li>
        </ul>
      </div>

      <!-- Columna: Newsletter -->
      <div class="col-md-4 text-center text-md-end">
        <h6 class="fw-semibold text-uppercase mb-3 small">Suscríbete</h6>
        <form class="newsletter-form" novalidate>
          <div class="input-group input-group-lg">
            <input type="email" class="form-control bg-dark border-0 text-light"
                   placeholder="Tu correo electrónico" required>
            <button class="btn btn-gradient" type="submit"><i class="bi bi-send"></i></button>
          </div>
          <small class="text-muted d-block mt-2" id="newsletter-msg"></small>
        </form>
      </div>
    </div>

    <hr class="my-5 border-secondary">

    <!-- Copy -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center small text-muted">
      <p class="mb-2 mb-md-0">© <span id="year"></span> OneContact. Todos los derechos reservados.</p>
      <div>
        <a href="#" class="footer-link">Privacidad</a> • 
        <a href="#" class="footer-link">Términos</a>
      </div>
    </div>
  </div>

  <!-- Botón volver arriba -->
  <button id="btnTop" class="btn btn-light btn-sm rounded-circle position-fixed shadow"
          style="width:48px;height:48px;bottom:25px;right:25px;display:none;opacity:0;transition:opacity .4s ease;"
          aria-label="Volver arriba">
    <i class="bi bi-arrow-up fs-5"></i>
  </button>
</footer>

<!-- ===== ESTILOS APPLE / ONECONTACT ===== -->
<style>
.footer-onecontact {
  background: radial-gradient(circle at top left, #0a0a0a 0%, #000 80%);
  font-family: "SF Pro Display", "Helvetica Neue", Arial, sans-serif;
  letter-spacing: 0.2px;
  opacity: 0;
  transform: translateY(30px);
  animation: fadeUp 1s ease-out forwards;
  backdrop-filter: blur(10px);
}
@keyframes fadeUp {
  to { opacity: 1; transform: translateY(0); }
}

/* Texto degradado */
.text-gradient {
  background: linear-gradient(135deg, #0072ff, #00c6ff);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* Enlaces */
.footer-link {
  color: rgba(255,255,255,.65);
  text-decoration: none;
  display: block;
  padding: 4px 0;
  transition: all .3s ease;
}
.footer-link:hover {
  color: #fff;
  transform: translateX(4px);
}

/* Social buttons */
.social-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border: 1px solid rgba(255,255,255,.25);
  border-radius: 50%;
  color: rgba(255,255,255,.8);
  font-size: 1rem;
  transition: all 0.35s ease;
}
.social-btn:hover {
  background: rgba(0,114,255,0.15);
  border-color: rgba(0,114,255,0.5);
  color: #00c6ff;
  transform: scale(1.15);
  box-shadow: 0 0 8px rgba(0,114,255,0.4);
}

/* Botón gradiente */
.btn-gradient {
  background: linear-gradient(135deg, #0072ff, #00c6ff);
  border: none;
  color: #fff;
  transition: all .3s ease;
}
.btn-gradient:hover {
  opacity: 0.9;
  transform: scale(1.05);
}

/* Input focus */
.footer-onecontact .form-control:focus {
  box-shadow: 0 0 0 .15rem rgba(0,123,255,.35);
}

/* Botón subir */
#btnTop {
  background: linear-gradient(135deg, #00c6ff, #0072ff);
  color: #fff;
  border: none;
  transition: all .3s ease;
}
#btnTop:hover {
  transform: scale(1.1);
  box-shadow: 0 0 12px rgba(0,114,255,0.6);
  opacity: 0.95;
}
</style>

<!-- ===== SCRIPTS ===== -->
<script>
// Año automático
document.getElementById('year').textContent = new Date().getFullYear();

// Newsletter
document.querySelector('.newsletter-form')?.addEventListener('submit', e => {
  e.preventDefault();
  const email = e.target.querySelector('input');
  const msg = document.getElementById('newsletter-msg');
  if (!email.value.includes('@')) {
    msg.textContent = 'Por favor, ingresa un correo válido.';
    msg.style.color = '#ff6b6b';
  } else {
    msg.textContent = '¡Gracias por suscribirte!';
    msg.style.color = '#00c6ff';
    e.target.reset();
  }
});

// Botón "Volver arriba"
(function() {
  const btn = document.getElementById('btnTop');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      btn.style.display = 'flex';
      setTimeout(() => btn.style.opacity = '1', 100);
    } else {
      btn.style.opacity = '0';
      setTimeout(() => btn.style.display = 'none', 300);
    }
  });
  btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
})();
</script>
