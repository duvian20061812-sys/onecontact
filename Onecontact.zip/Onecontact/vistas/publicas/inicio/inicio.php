<?php
  // include_once "vistas/publicas/inicio/modulos/navegacion.php";
  // include_once "modulos/login.php";
  include_once "modulos/navbar.php";
  include_once "modulos/team.php";
  include_once "modulos/servicios.php";
  include_once "modulos/footer.php";
?>

