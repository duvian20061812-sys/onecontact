<!-- =================== TEAM.PHP (Glassmorphism + Estilo Apple + OneContact) =================== -->
<section class="team-section">
  <div class="container text-center">
    <h2 class="team-title">Nuestro Equipo</h2>
    <p class="team-subtitle">Profesionales apasionados que impulsan la innovación en OneContact</p>

    <div class="team-grid">
      <!-- ====== INTEGRANTE 1 ====== -->
      <div class="team-card">
        <div class="team-img">
          <img src="vistas/recursos/img/team1.jpg" alt="Miembro del equipo">
        </div>
        <h4 class="team-name">Laura Fernández</h4>
        <p class="team-role">Gerente de Proyectos</p>
        <p class="team-desc">Coordina la innovación tecnológica y la comunicación con los clientes.</p>
      </div>

      <!-- ====== INTEGRANTE 2 ====== -->
      <div class="team-card">
        <div class="team-img">
          <img src="vistas/recursos/img/team2.jpg" alt="Miembro del equipo">
        </div>
        <h4 class="team-name">Carlos Pérez</h4>
        <p class="team-role">Líder de Desarrollo</p>
        <p class="team-desc">Experto en soluciones escalables y plataformas empresariales inteligentes.</p>
      </div>

      <!-- ====== INTEGRANTE 3 ====== -->
      <div class="team-card">
        <div class="team-img">
          <img src="vistas/recursos/img/team3.jpg" alt="Miembro del equipo">
        </div>
        <h4 class="team-name">Andrea Gómez</h4>
        <p class="team-role">UX / UI Designer</p>
        <p class="team-desc">Diseña experiencias visuales con fluidez y elegancia al estilo Apple.</p>
      </div>

      <!-- ====== INTEGRANTE 4 ====== -->
      <div class="team-card">
        <div class="team-img">
          <img src="vistas/recursos/img/team4.jpg" alt="Miembro del equipo">
        </div>
        <h4 class="team-name">Juan Rodríguez</h4>
        <p class="team-role">Especialista en Soporte</p>
        <p class="team-desc">Garantiza un servicio confiable y atención técnica de primer nivel.</p>
      </div>
    </div>
  </div>
</section>

<!-- ===== ESTILOS PERSONALIZADOS ===== -->
<style>
/* ===== Sección general ===== */
.team-section {
  min-height: 100vh;
  background: radial-gradient(circle at top left, #00132b, #000814 70%);
  color: #fff;
  padding: 100px 20px;
  position: relative;
  overflow: hidden;
}

/* Efecto luz suave tipo Apple */
.team-section::before {
  content: '';
  position: absolute;
  top: -10%;
  left: 30%;
  width: 300px;
  height: 300px;
  background: radial-gradient(circle, rgba(0, 153, 255, 0.3), transparent 60%);
  filter: blur(100px);
  z-index: 0;
}

/* ===== Títulos ===== */
.team-title {
  font-size: 2.5rem;
  font-weight: 700;
  letter-spacing: 1px;
  color: #00b7ff;
  text-shadow: 0 0 10px rgba(0,183,255,0.4);
  margin-bottom: 10px;
  animation: fadeDown 1s ease forwards;
}

.team-subtitle {
  color: rgba(255,255,255,0.7);
  max-width: 600px;
  margin: 0 auto 50px auto;
  font-size: 1.1rem;
  line-height: 1.5;
  animation: fadeDown 1.3s ease forwards;
}

/* ===== Grid del equipo ===== */
.team-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 40px;
  justify-items: center;
  position: relative;
  z-index: 1;
}

/* ===== Tarjetas Glassmorphism ===== */
.team-card {
  background: rgba(255,255,255,0.08);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 20px;
  padding: 25px;
  width: 260px;
  text-align: center;
  transition: all 0.5s ease;
  box-shadow: 0 8px 25px rgba(0,0,0,0.3);
  transform: translateY(30px);
  opacity: 0;
  animation: fadeUp 1s ease forwards;
}

.team-card:hover {
  transform: translateY(-10px) scale(1.03);
  border-color: rgba(0,183,255,0.4);
  box-shadow: 0 10px 40px rgba(0,183,255,0.2);
}

/* ===== Imagen circular ===== */
.team-img img {
  width: 110px;
  height: 110px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid rgba(0,183,255,0.4);
  margin-bottom: 15px;
  transition: transform 0.6s ease;
}

.team-card:hover img {
  transform: rotate(5deg) scale(1.05);
}

/* ===== Textos ===== */
.team-name {
  font-size: 1.2rem;
  font-weight: 600;
  margin-bottom: 5px;
}

.team-role {
  font-size: 0.95rem;
  color: #00b7ff;
  font-weight: 500;
  margin-bottom: 10px;
}

.team-desc {
  font-size: 0.9rem;
  color: rgba(255,255,255,0.75);
  line-height: 1.4;
}

/* ===== Animaciones tipo Apple ===== */
@keyframes fadeUp {
  0% { opacity: 0; transform: translateY(30px); }
  100% { opacity: 1; transform: translateY(0); }
}

@keyframes fadeDown {
  0% { opacity: 0; transform: translateY(-20px); }
  100% { opacity: 1; transform: translateY(0); }
}

/* ===== Adaptativo ===== */
@media (max-width: 768px) {
  .team-title { font-size: 2rem; }
  .team-card { width: 90%; }
}
</style>

<!-- ===== SCRIPT DE TRANSICIÓN SUAVE ===== -->
<script>
// Transiciones suaves al hacer scroll (tipo Apple)
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll('.team-card');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  cards.forEach(card => observer.observe(card));
});
</script>
