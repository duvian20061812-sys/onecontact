<!-- ================= SECCIÓN SERVICIOS ================= -->
<section id="servicios" class="position-relative py-5 overflow-hidden">
  <!-- Fondo dinámico con luces suaves tipo Apple -->
  <div class="position-absolute top-0 start-0 w-100 h-100" style="
      background:
        radial-gradient(800px 400px at 20% 10%, rgba(0,102,255,0.2), transparent),
        radial-gradient(600px 300px at 80% 20%, rgba(255,255,255,0.05), transparent),
        linear-gradient(180deg, rgba(0,0,0,0.9), rgba(10,10,20,1));
      filter: blur(20px);
      z-index: 0;">
  </div>

  <div class="container position-relative z-1 text-center text-light" style="max-width: 1150px;">
    <div class="mb-5" data-aos="fade-up" data-aos-duration="900">
      <h2 class="fw-semibold display-6 mb-2">Nuestros Servicios</h2>
      <p class="lead text-secondary">Innovación, diseño y tecnología para llevar tu marca al siguiente nivel.</p>
    </div>

    <div class="row g-4 justify-content-center">
      <!-- Servicio 1 -->
      <div class="col-12 col-sm-10 col-md-6 col-lg-4">
        <div class="servicio-card p-4 text-center h-100">
          <div class="icon-wrap mb-3"><i class="bi bi-display"></i></div>
          <h5 class="fw-bold mb-2">Diseño Web & Branding</h5>
          <p class="text-secondary small">Creamos experiencias digitales visualmente impecables, rápidas y modernas.</p>
          <ul class="list-unstyled small text-start mt-3 mb-4 text-secondary">
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Diseño centrado en la experiencia</li>
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Adaptación a cualquier dispositivo</li>
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Marca sólida y coherente</li>
          </ul>
          <a href="#contacto" class="btn btn-outline-light rounded-pill px-4 py-2">Ver más</a>
        </div>
      </div>

      <!-- Servicio 2 -->
      <div class="col-12 col-sm-10 col-md-6 col-lg-4">
        <div class="servicio-card p-4 text-center h-100">
          <div class="icon-wrap mb-3"><i class="bi bi-cpu"></i></div>
          <h5 class="fw-bold mb-2">Desarrollo & Automatización</h5>
          <p class="text-secondary small">Creamos sistemas robustos, escalables y con automatización inteligente.</p>
          <ul class="list-unstyled small text-start mt-3 mb-4 text-secondary">
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> APIs seguras y escalables</li>
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Integración con plataformas</li>
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Procesos automatizados</li>
          </ul>
          <a href="#contacto" class="btn btn-primary rounded-pill px-4 py-2">Empezar</a>
        </div>
      </div>

      <!-- Servicio 3 -->
      <div class="col-12 col-sm-10 col-md-6 col-lg-4">
        <div class="servicio-card p-4 text-center h-100">
          <div class="icon-wrap mb-3"><i class="bi bi-graph-up-arrow"></i></div>
          <h5 class="fw-bold mb-2">Analítica & Crecimiento</h5>
          <p class="text-secondary small">Medimos, optimizamos y potenciamos tu rendimiento digital con precisión.</p>
          <ul class="list-unstyled small text-start mt-3 mb-4 text-secondary">
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Reportes inteligentes</li>
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Estrategias de crecimiento</li>
            <li><i class="bi bi-check-circle-fill me-1 text-primary"></i> Optimización continua</li>
          </ul>
          <a href="#contacto" class="btn btn-outline-light rounded-pill px-4 py-2">Más información</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= ESTILOS PERSONALIZADOS ================= -->
<style>
/* Tarjeta principal con efecto glass */
.servicio-card {
  border-radius: 20px;
  background: rgba(255,255,255,0.06);
  backdrop-filter: blur(18px);
  border: 1px solid rgba(255,255,255,0.1);
  transition: all 0.6s cubic-bezier(0.25, 1, 0.3, 1);
  position: relative;
  overflow: hidden;
}

.servicio-card::before {
  content: "";
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 30% 20%, rgba(0,123,255,0.25), transparent 60%);
  opacity: 0;
  transition: opacity 0.6s ease;
}

.servicio-card:hover::before {
  opacity: 1;
}

.servicio-card:hover {
  transform: translateY(-10px) scale(1.02);
  box-shadow: 0 1.2rem 2.5rem rgba(0,0,0,0.25);
}

/* Icono elegante con reflejo tipo Apple */
.icon-wrap {
  width: 80px;
  height: 80px;
  border-radius: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2.2rem;
  color: #00c6ff;
  background: linear-gradient(145deg, rgba(255,255,255,0.08), rgba(0,0,0,0.2));
  box-shadow: inset 0 1px 3px rgba(255,255,255,0.1);
  transition: all .4s ease;
}

.servicio-card:hover .icon-wrap {
  color: #0072ff;
  transform: scale(1.1) rotate(-3deg);
  box-shadow: 0 0 20px rgba(0,123,255,0.5);
}

/* Transiciones tipo Apple */
.servicio-card, .icon-wrap, a.btn {
  transition: all 0.5s cubic-bezier(.4,0,.2,1);
}

/* Botones Apple style */
.btn-primary {
  background: linear-gradient(135deg, #0072ff, #00c6ff);
  border: none;
}
.btn-primary:hover {
  background: linear-gradient(135deg, #00c6ff, #0072ff);
}
.btn-outline-light:hover {
  background: rgba(255,255,255,0.1);
  color: #00c6ff !important;
}

/* Responsividad */
@media (max-width: 768px) {
  .servicio-card { margin-bottom: 1.5rem; }
}
</style>

<!-- Librerías opcionales para animaciones tipo Apple -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ once: true, duration: 900, easing: 'ease-out-cubic' });
</script>
