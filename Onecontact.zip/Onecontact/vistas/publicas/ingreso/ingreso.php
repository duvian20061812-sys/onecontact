<!-- ===== LOGIN CENTRADO (Bootstrap 5) ===== -->
<div class="d-flex align-items-center justify-content-center vh-100 login-bg" id="loginBackground">
  <div class="card shadow p-4 login-card">
    <div class="text-center mb-4">
      <img src="vistas/recursos/img/Onecontact.png" alt="Logo" width="100" class="mb-3">
      <h4 class="fw-bold text-primary">Iniciar sesión</h4>
      <p class="text-muted mb-0">Accede a tu cuenta</p>
    </div>

    <form method="POST">
      <div class="mb-3">
        <label for="email" class="form-label">Correo electrónico</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="usuario@empresa.com" required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Contraseña</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
      </div>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="remember" name="remember">
          <label class="form-check-label" for="remember">Recordarme</label>
        </div>
        <a href="#" class="text-decoration-none small text-primary">¿Olvidaste tu contraseña?</a>
      </div>

      <div class="d-grid mb-3">
        <button type="submit" class="btn btn-primary btn-login">Acceder</button>
      </div>

      <div class="text-center">
        <span class="small">¿No tienes cuenta? <a href="#" class="text-decoration-none text-primary">Regístrate</a></span>
      </div>

      <div class="text-center mt-2">
        <span class="small"><a href="inicio" class="text-decoration-none text-primary">Regresar al Inicio</a></span>
      </div>

      <?php
        $login = new ControladorUsuarios();
        $login -> ingresoUsuario();
      ?>

    </form>
  </div>
</div>

<!-- ===== ESTILOS PERSONALIZADOS ===== -->
<style>
/* Fondo general con degradado y overlay */
.login-bg {
  background: url('vistas/recursos/img/ctc.png') no-repeat center center fixed;
  background-size: cover;
  position: relative;
}

.login-bg::before {
  content: "";
  position: absolute;
  top:0; left:0;
  width:100%; height:100%;
  background: rgba(0, 0, 50, 0.5); /* overlay oscuro */
  z-index: 0;
}

/* Card centrada */
.login-card {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 400px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  color: #fff;
  border: 1px solid rgba(255,255,255,0.2);
}

/* Inputs y labels */
.form-control {
  border-radius: 25px;
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.3);
  color: #fff;
}
.form-control::placeholder {
  color: rgba(255,255,255,0.7);
}
.form-control:focus {
  border-color: #00c6ff;
  background: rgba(255,255,255,0.15);
  box-shadow: none;
}

/* Botón */
.btn-login {
  border-radius: 25px;
  padding: 12px;
  background: linear-gradient(135deg, #00c6ff, #0072ff);
  color: #fff;
  font-weight: 600;
  transition: 0.3s;
}
.btn-login:hover {
  background: linear-gradient(135deg, #0072ff, #00c6ff);
}

/* Links */
.text-primary {
  color: #00c6ff !important;
}
.text-primary:hover {
  color: #0072ff !important;
  text-decoration: underline;
}

/* Pequeños ajustes de textos */
.text-muted {
  color: rgba(255,255,255,0.7) !important;
}
</style>

<!-- ===== SCRIPT PARA FIJAR EL FONDO PERMANENTE ===== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const fondo = 'vistas/recursos/img/ctc.png';
  const contenedor = document.getElementById('loginBackground');

  // Si no está guardado en localStorage, lo guarda
  if (!localStorage.getItem('fondoFijo')) {
    localStorage.setItem('fondoFijo', fondo);
  }

  // Aplica siempre el fondo guardado
  const fondoGuardado = localStorage.getItem('fondoFijo');
  contenedor.style.backgroundImage = `url('${fondoGuardado}')`;
  contenedor.style.backgroundRepeat = 'no-repeat';
  contenedor.style.backgroundPosition = 'center center';
  contenedor.style.backgroundAttachment = 'fixed';
  contenedor.style.backgroundSize = 'cover';

  // Reaplica si se vuelve atrás o se recarga
  window.addEventListener('pageshow', () => {
    const fondoGuardado2 = localStorage.getItem('fondoFijo');
    contenedor.style.backgroundImage = `url('${fondoGuardado2}')`;
  });
});
</script>
