<!-- Topbar -->
<nav class="navbar navbar-expand navbar-dark topbar shadow"
     style="background-color: #001F3F; transition: all 0.6s cubic-bezier(.25,.1,.25,1);z-index:9999;">

  <!-- Sidebar Toggle (Topbar) -->
  <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle me-3"
          style="color: rgba(255,255,255,0.9); transition: color 0.3s ease;">
      <i class="fa fa-bars"></i>
  </button>

  <!-- Topbar Search -->
  <form class="d-none d-sm-inline-block form-inline ms-md-3 my-2 my-md-0 mw-100 navbar-search">
      <div class="input-group" style="transition: transform 0.3s ease;">
          <input type="text" class="form-control bg-light border-0 small"
                 placeholder="Buscar..." aria-label="Search" aria-describedby="basic-addon2"
                 style="transition: box-shadow 0.3s ease;">
          <div class="input-group-append">
              <button class="btn btn-light" type="button"
                      style="transition: background-color 0.3s ease, transform 0.3s ease;">
                  <i class="fas fa-search fa-sm"></i>
              </button>
          </div>
      </div>
  </form>

  <!-- Topbar Navbar -->
  <ul class="navbar-nav ms-auto">

      <!-- Nav Item - Alerts -->
      <li class="nav-item dropdown no-arrow mx-1">
          <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
             data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
             style="color: rgba(255,255,255,0.85); transition: color 0.3s ease, transform 0.3s ease;">
             <i class="bi bi-bell"></i>
              <span class="badge bg-danger badge-counter">3+</span>
          </a>
          <div class="dropdown-menu dropdown-menu-end shadow animated--grow-in"
               aria-labelledby="alertsDropdown">
              <h6 class="dropdown-header">Centro de Alertas</h6>
              <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="me-3">
                      <div class="icon-circle bg-primary">
                          <i class="fas fa-file-alt text-white"></i>
                      </div>
                  </div>
                  <div>
                      <div class="small text-gray-500">12 Dic 2024</div>
                      <span class="fw-bold">Nuevo reporte mensual disponible</span>
                  </div>
              </a>
          </div>
      </li>

      <!-- Nav Item - Messages -->
      <li class="nav-item dropdown no-arrow mx-1">
          <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
             data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
             style="color: rgba(255,255,255,0.85); transition: color 0.3s ease, transform 0.3s ease;">
             <i class="bi bi-chat-dots-fill text-primary"
   style="
     font-size: 20px;
     color: #00aaff;
     text-shadow:
        0 0 8px #00aaff,
        0 0 16px #0099ff,
        0 0 24px #00ccff;
     transition: all 0.4s ease-in-out;
     cursor: pointer;
   "
   onmouseover="this.style.transform='scale(1.2) rotate(5deg)'; 
                this.style.color='#66ffff'; 
                this.style.textShadow='0 0 10px #33ffff, 0 0 25px #00e6e6, 0 0 40px #66ffff';"
   onmouseout="this.style.transform='scale(1) rotate(0deg)'; 
               this.style.color='#00aaff';
               this.style.textShadow='0 0 8px #00aaff, 0 0 16px #0099ff, 0 0 24px #00ccff';">
</i>

              <span class="badge bg-danger badge-counter">7</span>
          </a>
          <div class="dropdown-menu dropdown-menu-end shadow animated--grow-in"
               aria-labelledby="messagesDropdown">
              <h6 class="dropdown-header">Centro de Mensajes</h6>
              <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image me-3">
                      <img class="rounded-circle" src="vistas/recursos/img/undraw_profile_1.svg" alt="...">
                      <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="fw-bold">
                      <div class="text-truncate">¡Hola! ¿Puedes ayudarme con un tema?</div>
                      <div class="small text-gray-500">Emily Fowler · 58m</div>
                  </div>
              </a>
          </div>
      </li>

      <div class="topbar-divider d-none d-sm-block"></div>

      <!-- Nav Item - User Information -->
      <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
             data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
             style="color: rgba(255,255,255,0.9); transition: color 0.3s ease, transform 0.3s ease;">
              <span class="me-2 d-none d-lg-inline small"
                    style="color: rgba(255,255,255,0.9);"><?= ucwords($_SESSION['usuario']) ?></span>
              <img class="img-profile rounded-circle"
                   src="vistas/recursos/img/undraw_profile.svg"
                   style="width: 36px; height: 36px; transition: transform 0.3s ease;">
          </a>
          <div class="dropdown-menu dropdown-menu-end shadow animated--grow-in"
               aria-labelledby="userDropdown">
              <a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i> Perfil</a>
              <a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i> Configuración</a>
              <a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i> Actividad</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="salir">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i> Salir
              </a>
          </div>
      </li>

  </ul>
</nav>
<!-- End of Topbar -->


