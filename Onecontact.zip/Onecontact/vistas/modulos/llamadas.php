<?php
// llamadas-section.php
header('Content-Type: text/html; charset=UTF-8');

/**
 * Zona de llamadas dinámica
 * Versión: 1.0.1
 * Fecha: 13/11/2025
 */

$callHistory = [
  [
    'name' => 'Ana García',
    'avatar' => 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    'type' => 'Entrante',
    'time' => 'Hace 5 min',
    'status' => 'completada',
    'duration' => '3:45',
  ],
  [
    'name' => 'Carlos López',
    'avatar' => 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    'type' => 'Saliente',
    'time' => 'Hace 20 min',
    'status' => 'perdida',
    'duration' => '--',
  ],
  [
    'name' => 'María Rodríguez',
    'avatar' => 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    'type' => 'Entrante',
    'time' => 'Hace 1 h',
    'status' => 'completada',
    'duration' => '6:22',
  ],
];
?>

<div class="animate-fadeIn">
  <div class="border border-neutral-200/50 dark:border-neutral-800/50 rounded-2xl bg-white/60 dark:bg-black/60 backdrop-blur-xl shadow-sm hover:shadow-lg hover:shadow-blue-500/5 transition-all duration-300">
    <div class="flex items-center justify-between px-6 py-4 border-b border-neutral-200/50 dark:border-neutral-800/50">
      <div>
        <h2 class="text-neutral-900 dark:text-white font-semibold text-lg">📞 Llamadas</h2>
        <p class="text-sm text-neutral-500 dark:text-neutral-400">Historial de llamadas recientes</p>
      </div>
      <button class="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#007aff] to-[#00c6ff] text-white text-sm shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
        <i data-lucide="phone" class="w-4 h-4"></i>
        Nueva llamada
      </button>
    </div>

    <div class="divide-y divide-neutral-200/50 dark:divide-neutral-800/50">
      <?php foreach ($callHistory as $call): ?>
      <div class="flex items-center gap-4 px-6 py-4 hover:bg-neutral-100/50 dark:hover:bg-neutral-900/50 transition-all duration-300 cursor-pointer group">
        <img src="<?= $call['avatar'] ?>" alt="<?= $call['name'] ?>" class="w-12 h-12 rounded-full border-2 border-white dark:border-neutral-900 shadow-sm">
        <div class="flex-1 min-w-0">
          <p class="text-sm font-medium text-neutral-900 dark:text-white truncate"><?= $call['name'] ?></p>
          <p class="text-xs text-neutral-500 dark:text-neutral-400"><?= $call['type'] ?> • <?= $call['time'] ?></p>
        </div>
        <div class="flex items-center gap-4">
          <span class="text-xs text-neutral-500 dark:text-neutral-400"><?= $call['duration'] ?></span>
          <?php if ($call['status'] === 'completada'): ?>
            <span class="px-2 py-1 text-xs bg-green-500/10 text-green-600 dark:text-green-400 rounded-full flex items-center gap-1">
              <i data-lucide="check-circle" class="w-3.5 h-3.5"></i> Completada
            </span>
          <?php elseif ($call['status'] === 'perdida'): ?>
            <span class="px-2 py-1 text-xs bg-red-500/10 text-red-600 dark:text-red-400 rounded-full flex items-center gap-1">
              <i data-lucide="x-circle" class="w-3.5 h-3.5"></i> Perdida
            </span>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script>
  lucide.createIcons();
</script>

<style>
  .animate-fadeIn {
    animation: fadeIn 0.5s ease-in-out;
  }
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
</style>
