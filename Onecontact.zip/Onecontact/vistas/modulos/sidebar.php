        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" style="background: #000; backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border-right: 3px solid #003366; box-shadow: 5px 0 15px rgba(0, 51, 102, 0.5), inset -1px 0 0 rgba(255, 255, 255, 0.1); position: relative;" id="accordionSidebar">
        <div style="content: ''; position: absolute; top: 0; bottom: 0; right: -3px; width: 3px; background: linear-gradient(180deg, #003366, #0066cc, #003366); box-shadow: 0 0 10px rgba(0, 51, 102, 0.8);"></div>

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard">
                <div class="sidebar-brand-icon rotate-n-18">
                    <!-- <i class="fas fa-laugh-wink"></i> -->
                    <img src="vistas/recursos/img/Onecontact.png" alt="" width="50px">
                </div>
                <div class="sidebar-brand-text mx-3">Onecontact</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <!-- <li class="nav-item">
                <a class="nav-link" href="dashboard">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li> -->

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Usuarios -->
            <!-- <li class="nav-item">
                <a class="nav-link" href="usuarios">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Usuarios</span></a>
            </li> -->

            <!-- Divider -->
            <hr class="sidebar-divider">



            <!-- Heading -->
            <div class="sidebar-heading">
                Inventario
            </div>

            <!-- Categorías -->
            <li class="nav-item">
                <a class="nav-link" href="categorias">
                <i class="bi bi-list"></i>
                    <span>Categorías</span></a>
            </li>

            <!-- Productos -->
            <li class="nav-item">
                <a class="nav-link" href="productos">
                <i class="bi bi-box-seam-fill"></i>
                    <span>Productos</span></a>
            </li>


            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->

            <!-- Clientes -->
            <!-- <li class="nav-item">
                <a class="nav-link" href="clientes">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Clientes</span></a>
            </li> -->

            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->


            <!-- Ventas -->
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Ventas</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Gestión de ventas:</h6>
                        <a class="collapse-item" href="ventas">Administrar ventas</a>
                        <a class="collapse-item" href="crear-venta">Crear Venta</a>
                        <a class="collapse-item" href="reportes">Reporte de Ventas</a>
                    </div>
                </div>
            </li> -->

            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->

            <!-- Salir -->
            <li class="nav-item">
                <a class="nav-link" href="salir">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Salir</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>