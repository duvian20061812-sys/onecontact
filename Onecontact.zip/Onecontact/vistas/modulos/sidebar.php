<?php
$quickStats = [
    ["label" => "Pendientes", "value" => 23, "icon" => "clock", "color" => "text-orange-400", "bg" => "bg-orange-500/10"],
    ["label" => "Completados", "value" => 156, "icon" => "check-circle-2", "color" => "text-green-400", "bg" => "bg-green-500/10"],
    ["label" => "Urgentes", "value" => 8, "icon" => "alert-circle", "color" => "text-red-400", "bg" => "bg-red-500/10"]
];

$menuItems = [
    ["icon" => "home", "label" => "Dashboard", "active" => true, "badge" => null],
    ["icon" => "users", "label" => "Contactos", "active" => false, "badge" => "2.4K"],
    ["icon" => "message-square", "label" => "Mensajes", "active" => false, "badge" => "12"],
    ["icon" => "phone", "label" => "Llamadas", "active" => false, "badge" => null],
    ["icon" => "mail", "label" => "Emails", "active" => false, "badge" => "5"],
    ["icon" => "calendar", "label" => "Calendario", "active" => false, "badge" => null],
    ["icon" => "bar-chart-3", "label" => "Analytics", "active" => false, "badge" => null],
    ["icon" => "settings", "label" => "Configuración", "active" => false, "badge" => null],
];
?>

<!-- ================ SIDEBAR APPLE DARK ================ -->
<aside id="sidebar"
  class="fixed inset-y-0 left-0 z-50 w-72 bg-black/80 backdrop-blur-2xl border-r border-white/10 shadow-2xl transform -translate-x-full transition-all duration-500 lg:translate-x-0">

  <!-- Logo -->
  <div class="flex items-center justify-between px-6 py-6 border-b border-white/10">
    <div class="flex items-center gap-3">
      <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#007aff] to-[#00c6ff] flex items-center justify-center shadow-lg shadow-blue-500/30 animate-soft-float">
        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M21 15a2 2 0 0 1-2 2h-4l-4 4v-4H5a2 2 0 0 1-2-2V5a2
          2 0 0 1 2-2h14a2 2 0 0 1 2 2Z"/>
        </svg>
      </div>
      <div>
        <h1 class="bg-gradient-to-r from-[#007aff] to-[#00c6ff] bg-clip-text text-transparent font-semibold">
          OneContact
        </h1>
        <p class="text-xs text-white/40">Pro Plan</p>
      </div>
    </div>

    <button onclick="toggleSidebar()" class="lg:hidden text-white/60 hover:text-white">
      ✕
    </button>
  </div>

  <!-- Quick Stats -->
  <div class="px-4 py-4 border-b border-white/10">
    <div class="grid grid-cols-3 gap-2">
      <?php foreach ($quickStats as $stat): ?>
        <div class="p-3 rounded-xl <?= $stat['bg'] ?> border border-white/5 backdrop-blur-xl hover:scale-[1.03] transition-all duration-300">
          
          <div class="text-white/50 mb-1">
            <i class="lucide lucide-<?= $stat["icon"] ?> <?= $stat["color"] ?> w-4 h-4"></i>
          </div>

          <p class="text-xs text-white/50"><?= $stat["label"] ?></p>
          <p class="text-lg text-white"><?= $stat["value"] ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Menu -->
  <nav class="flex-1 px-3 py-4 space-y-1 overflow-y-auto custom-scrollbar">
    <?php foreach ($menuItems as $item): ?>
      <a href="#"
         class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden
         <?= $item["active"]
            ? 'bg-gradient-to-r from-[#007aff] to-[#00c6ff] text-white shadow-lg shadow-blue-500/30'
            : 'text-white/60 hover:bg-white/5 hover:text-white'
          ?>">
          
        <i class="lucide lucide-<?= $item["icon"] ?> w-5 h-5 relative z-10"></i>
        <span class="text-sm flex-1 relative z-10"><?= $item["label"] ?></span>

        <?php if ($item["badge"]): ?>
          <span class="text-xs px-2 py-0.5 rounded-lg
            <?= $item["active"]
                ? 'bg-white/20 text-white'
                : 'bg-[#007aff]/20 text-[#00c6ff]' ?>">
            <?= $item["badge"] ?>
          </span>
        <?php endif; ?>

      </a>
    <?php endforeach; ?>
  </nav>

  <!-- User -->
  <div class="p-4 border-t border-white/10">
    <div class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-white/5 transition-all duration-300 cursor-pointer">
      
      <div class="relative">
        <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100"
             class="w-11 h-11 rounded-full border-2 border-[#007aff]/30 ring-2 ring-[#007aff]/20">
        <span class="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-black"></span>
      </div>

      <div class="flex-1">
        <p class="text-sm text-white">Admin User</p>
        <p class="text-xs text-white/40">admin@onecontact.com</p>
      </div>

      <i class="lucide lucide-chevron-right text-white/40"></i>
    </div>
  </div>
</aside>

<!-- Overlay Mobile -->
<div id="overlay"
     onclick="toggleSidebar()"
     class="fixed inset-0 bg-black/70 backdrop-blur-sm hidden lg:hidden"></div>

<style>
/* Smooth Apple Floating */
@keyframes softFloat {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-4px); }
  100% { transform: translateY(0px); }
}
.animate-soft-float { animation: softFloat 3s ease-in-out infinite; }

/* Scrollbar Apple */
.custom-scrollbar::-webkit-scrollbar { width: 6px; }
.custom-scrollbar::-webkit-scrollbar-track { background: rgba(255,255,255,.05); }
.custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,122,255,.5); border-radius: 10px; }

/* Sidebar Toggle */
</style>

<script>
function toggleSidebar() {
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("overlay");

  if (sidebar.classList.contains("-translate-x-full")) {
    sidebar.classList.remove("-translate-x-full");
    overlay.classList.remove("hidden");
  } else {
    sidebar.classList.add("-translate-x-full");
    overlay.classList.add("hidden");
  }
}
</script>

