<?/**
 * Sección principal del Dashboard
 * Limpia, sin sidebar ni header
 * Estilo: Apple / Tailwind / Chart.js
 */
?>



<!-- DASHBOARD -->
<main class="lg:ml-72 p-6 bg-[#0a0a0a] min-h-screen text-white transition-all duration-300">
  <!-- TITULO -->
  <div class="flex justify-between items-center">
    <div>
      <h2 class="text-2xl font-semibold">Dashboard de Comunicaciones</h2>
      <p class="text-neutral-500 text-sm">Gestión de métricas y rendimiento</p>
    </div>
    <div class="hidden md:flex items-center gap-2 text-sm text-neutral-500">
      <i data-lucide="clock" class="w-4 h-4"></i>
      Actualizado hace 2 min
    </div>
  </div>

  <!-- ESTADÍSTICAS -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
    <?php
    $stats = [
      ["title" => "Contactos Activos", "value" => "12,458", "change" => "+18.2%", "color" => "from-blue-500 to-cyan-500", "icon" => "users"],
      ["title" => "Mensajes Enviados", "value" => "8,234", "change" => "+24.5%", "color" => "from-purple-500 to-pink-500", "icon" => "message-square"],
      ["title" => "Llamadas Hoy", "value" => "342", "change" => "+12.3%", "color" => "from-green-500 to-emerald-500", "icon" => "phone"],
      ["title" => "Tasa de Respuesta", "value" => "94.2%", "change" => "+5.8%", "color" => "from-orange-500 to-red-500", "icon" => "zap"],
    ];

    foreach ($stats as $s): ?>
      <div class="p-6 rounded-2xl bg-white/60 dark:bg-black/60 backdrop-blur-xl border border-neutral-200/50 dark:border-neutral-800/50 hover:shadow-xl hover:shadow-blue-500/5 transition-transform hover:-translate-y-1 duration-300">
        <div class="flex justify-between mb-4">
          <div class="w-12 h-12 rounded-xl bg-gradient-to-br <?= $s['color'] ?> flex items-center justify-center shadow-lg">
            <i data-lucide="<?= $s['icon'] ?>" class="w-6 h-6 text-white"></i>
          </div>
          <span class="text-green-600 text-sm font-semibold"><?= $s['change'] ?></span>
        </div>
        <h3 class="text-2xl font-semibold"><?= $s['value'] ?></h3>
        <p class="text-neutral-500 text-sm"><?= $s['title'] ?></p>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- GRÁFICOS -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <div class="lg:col-span-2 bg-white/60 dark:bg-black/60 border border-neutral-200/50 dark:border-neutral-800/50 rounded-2xl p-4 backdrop-blur-xl hover:shadow-xl transition">
    <h3 class="font-semibold mb-2">Comunicaciones Semanales</h3>
    <canvas id="comChart" height="220"></canvas>
  </div>

  <div class="bg-white/60 dark:bg-black/60 border border-neutral-200/50 dark:border-neutral-800/50 rounded-2xl p-4 backdrop-blur-xl hover:shadow-xl transition">
    <h3 class="font-semibold mb-2">Tiempo de Respuesta (min)</h3>
    <canvas id="respChart" height="200"></canvas>
  </div>
</div>


<!-- Librerías -->
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  lucide.createIcons();

  // Gráfico 1 - Comunicaciones Semanales
  new Chart(document.getElementById('comChart'), {
    type: 'bar',
    data: {
      labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
      datasets: [
        { label: 'Mensajes', data: [420,380,520,480,590,320,280], backgroundColor: '#007aff' },
        { label: 'Llamadas', data: [180,150,200,190,220,140,120], backgroundColor: '#00c6ff' },
        { label: 'Emails', data: [240,220,280,260,310,180,160], backgroundColor: '#a855f7' },
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' } },
      scales: { y: { beginAtZero: true } }
    }
  });

  // Gráfico 2 - Tiempo de Respuesta
  new Chart(document.getElementById('respChart'), {
    type: 'line',
    data: {
      labels: ['9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00'],
      datasets: [{
        label: 'Tiempo de Respuesta',
        data: [45,38,52,65,42,35,40,48],
        borderColor: '#00c6ff',
        backgroundColor: 'rgba(0,198,255,0.2)',
        tension: 0.4,
        fill: true,
        pointRadius: 5
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
</script>
