<?php
// categorias.php
// Ubicación sugerida: /ruta/a/proyecto/categorias/categorias.php

// -------------------------
// CONFIG / CONEXIÓN PDO
// -------------------------
$hasConexionClass = file_exists(__DIR__ . '/../Modelos/Conexion.php') || file_exists(__DIR__ . '/Modelos/Conexion.php');

if ($hasConexionClass) {
    if (file_exists(__DIR__ . '/../Modelos/Conexion.php')) {
        require_once __DIR__ . '/../Modelos/Conexion.php';
    } else {
        require_once __DIR__ . '/Modelos/Conexion.php';
    }
    // Esperamos que Conexion::pdo() exista
    try {
        $pdo = Conexion::pdo();
    } catch (Throwable $e) {
        $pdo = null;
    }
} else {
    // FALLBACK: configura tus credenciales si no usas Conexion.php
    $dbHost = '127.0.0.1';
    $dbName = 'inventario';
    $dbUser = 'root';
    $dbPass = '';
    $dbCharset = 'utf8mb4';

    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=$dbCharset";
    try {
        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (PDOException $e) {
        // Si falla la DB, mostraremos un mensaje en la UI
        $pdo = null;
    }
}

// -------------------------
// RUTINAS CRUD (POST)
// -------------------------
$errors = [];
$success = null;

// Crear categoría
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $name = trim($_POST['categoria'] ?? '');
    if ($name === '') {
        $errors[] = 'El nombre de la categoría no puede estar vacío.';
    } else {
        if ($pdo) {
            try {
                // Evitar duplicados simples
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM categorias WHERE LOWER(nombre_categoria) = LOWER(:n)");
                $stmt->execute([':n' => $name]);
                if ((int)$stmt->fetchColumn() > 0) {
                    $errors[] = 'Ya existe una categoría con ese nombre.';
                } else {
                    $ins = $pdo->prepare("INSERT INTO categorias (nombre_categoria) VALUES (:n)");
                    $ins->execute([':n' => $name]);
                    $success = 'Categoría creada correctamente.';
                }
            } catch (PDOException $e) {
                $errors[] = 'Error al crear: ' . $e->getMessage();
            }
        } else {
            $errors[] = 'Sin conexión a la base de datos.';
        }
    }
}

// Editar categoría
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)($_POST['id_categoria'] ?? 0);
    $name = trim($_POST['categoria'] ?? '');
    if ($id <= 0 || $name === '') {
        $errors[] = 'ID inválido o nombre vacío.';
    } else {
        if ($pdo) {
            try {
                // Evitar duplicados excepto su propio id
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM categorias WHERE LOWER(nombre_categoria)=LOWER(:n) AND id_categoria <> :id");
                $stmt->execute([':n' => $name, ':id' => $id]);
                if ((int)$stmt->fetchColumn() > 0) {
                    $errors[] = 'Otra categoría ya usa ese nombre.';
                } else {
                    $up = $pdo->prepare("UPDATE categorias SET nombre_categoria = :n WHERE id_categoria = :id");
                    $up->execute([':n' => $name, ':id' => $id]);
                    $success = 'Categoría actualizada correctamente.';
                }
            } catch (PDOException $e) {
                $errors[] = 'Error al actualizar: ' . $e->getMessage();
            }
        } else {
            $errors[] = 'Sin conexión a la base de datos.';
        }
    }
}

// Eliminar categoría
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = (int)($_POST['id_categoria_eliminar'] ?? 0);
    if ($id <= 0) {
        $errors[] = 'ID inválido.';
    } else {
        if ($pdo) {
            try {
                $del = $pdo->prepare("DELETE FROM categorias WHERE id_categoria = :id");
                $del->execute([':id' => $id]);
                if ($del->rowCount() > 0) {
                    $success = 'Categoría eliminada.';
                } else {
                    $errors[] = 'No se encontró la categoría o no se pudo eliminar.';
                }
            } catch (PDOException $e) {
                $errors[] = 'Error al eliminar: ' . $e->getMessage();
            }
        } else {
            $errors[] = 'Sin conexión a la base de datos.';
        }
    }
}

// -------------------------
// Obtener todas las categorías
// -------------------------
$categorias = [];
if ($pdo) {
    try {
        $stmt = $pdo->query("SELECT id_categoria, nombre_categoria, fyh_creacion_categoria FROM categorias ORDER BY id_categoria DESC");
        $categorias = $stmt->fetchAll();
    } catch (PDOException $e) {
        $errors[] = 'Error al leer categorías: ' . $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Gestión de Categorías — Apple Dark</title>

  <!-- Bootstrap 5 (CDN) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- DataTables CSS -->
  <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

  <!-- FontAwesome para iconos -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
  /* -------------------- Apple Dark Theme (scoped to .apple-dark-theme) -------------------- */
  :root {
    --apple-bg: #0d0d0f;
    --apple-card: rgba(255,255,255,0.04);
    --apple-card-border: rgba(255,255,255,0.08);
    --apple-text: #e5e5e7;
    --apple-sub: #9aa0a6;
    --apple-primary: #0a84ff;
    --apple-success: #30d158;
    --apple-danger: #ff3b47;
    --apple-blur: blur(18px);
  }

  body { background: #070708; color: var(--apple-text); font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; }

  .apple-dark-theme { padding: 24px; }

  .apple-card {
    background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
    border: 1px solid var(--apple-card-border);
    backdrop-filter: var(--apple-blur);
    border-radius: 14px;
    box-shadow: 0 10px 30px rgba(2,6,23,0.6);
    transition: transform 280ms cubic-bezier(.2,.9,.3,1), box-shadow 280ms cubic-bezier(.2,.9,.3,1);
  }
  .apple-card:hover { transform: translateY(-4px); box-shadow: 0 18px 40px rgba(2,6,23,0.7); }

  .page-header { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:18px; }
  .page-title { display:flex; align-items:center; gap:12px; font-size:1.15rem; font-weight:600; color:var(--apple-text); }
  .page-sub { color:var(--apple-sub); margin:0; font-size:.95rem; }

  /* Table */
  .dataTables_wrapper .dataTables_length label,
  .dataTables_wrapper .dataTables_filter label,
  .dataTables_wrapper .dataTables_info,
  .dataTables_wrapper .dataTables_paginate a,
  .dataTables_wrapper .dataTables_paginate span,
  .dataTables_wrapper .paginate_button {
      color: #ffffff !important;
  }
  .apple-dark-theme table.dataTable thead th { background: rgba(255,255,255,0.03); color: var(--apple-text); border-bottom: 1px solid rgba(255,255,255,0.04); }
  .apple-dark-theme .table { color: var(--apple-text); }

  /* Fix select */
  .dataTables_length select {
    background: rgba(255,255,255,0.06) !important;
    color: #fff !important;
    border: 1px solid rgba(255,255,255,0.12) !important;
    border-radius: 10px !important;
    height: 38px !important;
    min-height: 38px !important;
    padding: 6px 12px !important;
    font-size: 14px !important;
    line-height: 24px !important;
    box-sizing: border-box !important;
    appearance: none !important;
    -webkit-appearance: none !important;
    padding-right: 36px !important;
    background-image: linear-gradient(45deg, transparent 50%, #fff 50%), linear-gradient(135deg, #fff 50%, transparent 50%);
    background-position: calc(100% - 16px) calc(50% - 6px), calc(100% - 12px) calc(50% - 6px);
    background-size: 6px 6px, 6px 6px;
    background-repeat: no-repeat;
  }

  /* Search input */
  .dataTables_filter input {
    background: rgba(255,255,255,0.04) !important;
    color: #fff !important;
    border: 1px solid rgba(255,255,255,0.08) !important;
    border-radius: 10px !important;
    padding: 8px 12px !important;
  }

  /* Buttons */
  .btn-apple {
    background: linear-gradient(180deg, var(--apple-primary), #0068d6);
    border: none;
    color: white;
    padding: 8px 12px;
    border-radius: 10px;
    box-shadow: 0 8px 30px rgba(10,132,255,0.18);
    transition: transform 180ms ease, box-shadow 180ms ease;
  }
  .btn-apple:hover { transform: translateY(-2px); box-shadow: 0 18px 40px rgba(10,132,255,0.22); }

  .btn-outline-apple {
    color: var(--apple-primary);
    border: 1px solid rgba(10,132,255,0.22);
    background: transparent;
    border-radius: 10px;
  }

  /* Inputs / form */
  .form-control.apple {
    background: rgba(255,255,255,0.02);
    border: 1px solid rgba(255,255,255,0.06);
    color: var(--apple-text);
    border-radius: 10px;
    padding: 10px 12px;
    transition: box-shadow .18s ease, border-color .18s ease, transform .18s ease;
  }
  .form-control.apple:focus { box-shadow: 0 6px 20px rgba(10,132,255,0.08); border-color: var(--apple-primary); transform: translateY(-1px); outline: none; }

  /* Cards inside layout */
  .panel { padding:16px; border-radius:12px; }
  .panel-header { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:12px; }

  /* small text */
  .muted { color: var(--apple-sub); font-size:.92rem; }

  /* Modal tweaks */
  .modal-content { background: rgba(6,6,7,0.85); border: 1px solid rgba(255,255,255,0.04); border-radius:14px; color:var(--apple-text); }
  .modal-backdrop.show { backdrop-filter: blur(6px); }

  /* Responsive tweaks */
  @media (max-width: 768px) {
    .page-title { font-size:1rem; }
  }

  </style>
</head>
<body>
  <div class="apple-dark-theme container-fluid">

    <!-- Header -->
    <div class="page-header">
      <div>
        <div class="page-title"><i class="fa-solid fa-tags" style="color:var(--apple-primary)"></i> Gestión de Categorías</div>
        <div class="muted">Administra las categorías del inventario</div>
      </div>
      <div class="d-flex gap-2 align-items-center">
        <button class="btn btn-apple" data-bs-toggle="modal" data-bs-target="#modalCreate"><i class="fa-solid fa-plus me-2"></i>Nueva categoría</button>
      </div>
    </div>

    <!-- Mensajes -->
    <?php if ($success): ?>
      <div class="alert alert-success apple-card" role="alert"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>
    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger apple-card" role="alert">
        <ul class="mb-0">
          <?php foreach ($errors as $err): ?>
            <li><?=htmlspecialchars($err)?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <!-- Main panel -->
    <div class="apple-card panel">
      <div class="panel-header">
        <h5 class="mb-0">Listado</h5>
        <div class="muted">Total: <?=count($categorias)?></div>
      </div>

      <div class="table-responsive">
        <table id="dtCategorias" class="table table-borderless table-hover" style="width:100%">
          <thead>
            <tr>
              <th style="width:60px;">#</th>
              <th>Nombre</th>
              <th style="width:160px">Creado</th>
              <th style="width:140px" class="text-end">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($categorias)): $i=1; foreach ($categorias as $cat): ?>
              <tr data-id="<?= (int)$cat['id_categoria'] ?>">
                <td class="align-middle"><?= $i ?></td>
                <td class="align-middle"><?= htmlspecialchars($cat['nombre_categoria']) ?></td>
                <td class="align-middle"><small class="muted"><?= htmlspecialchars($cat['fyh_creacion_categoria']) ?></small></td>
                <td class="align-middle text-end">
                  <button class="btn btn-sm btn-outline-apple me-1 btn-edit" data-id="<?= (int)$cat['id_categoria'] ?>" data-name="<?= htmlspecialchars($cat['nombre_categoria'], ENT_QUOTES) ?>"><i class="fa-solid fa-edit"></i></button>
                  <button class="btn btn-sm btn-outline-danger btn-delete" data-id="<?= (int)$cat['id_categoria'] ?>"><i class="fa-solid fa-trash"></i></button>
                </td>
              </tr>
            <?php $i++; endforeach; else: ?>
              <tr><td colspan="4" class="text-center muted">No hay categorías registradas.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- MODAL CREATE -->
    <div class="modal fade" id="modalCreate" tabindex="-1">
      <div class="modal-dialog modal-sm modal-dialog-centered">
        <form method="post" class="modal-content">
          <input type="hidden" name="action" value="create">
          <div class="modal-header">
            <h5 class="modal-title">Crear categoría</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label class="form-label">Nombre</label>
            <input type="text" name="categoria" class="form-control apple" required>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-apple btn-sm">Crear</button>
          </div>
        </form>
      </div>
    </div>

    <!-- MODAL EDIT -->
    <div class="modal fade" id="modalEdit" tabindex="-1">
      <div class="modal-dialog modal-sm modal-dialog-centered">
        <form method="post" class="modal-content" id="formEdit">
          <input type="hidden" name="action" value="edit">
          <input type="hidden" name="id_categoria" id="editId">
          <div class="modal-header">
            <h5 class="modal-title">Editar categoría</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label class="form-label">Nombre</label>
            <input type="text" name="categoria" id="editName" class="form-control apple" required>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-apple btn-sm">Guardar</button>
          </div>
        </form>
      </div>
    </div>

    <!-- FORM DELETE (POST clásico) -->
    <form id="formDelete" method="post" class="d-none">
      <input type="hidden" name="action" value="delete">
      <input type="hidden" name="id_categoria_eliminar" id="delId">
    </form>

  </div> <!-- /apple-dark-theme -->

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

  <script>
    // DataTable init
    $(document).ready(function() {
      const table = $('#dtCategorias').DataTable({
        pageLength: 10,
        lengthMenu: [ [10,25,50,100], [10,25,50,100] ],
        language: {
          url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json"
        },
        // dom adjusted to group length and filter inside container for styling
        dom: '<"d-flex justify-content-between mb-2"l f>t<"d-flex justify-content-between mt-2"i p>',
        columnDefs: [
          { orderable: false, targets: [3] }
        ]
      });

      // fix: re-draw to ensure custom styles apply
      table.draw();
    });

    // Abrir modal editar y rellenar campos
    document.addEventListener('click', function(e) {
      const editBtn = e.target.closest('.btn-edit');
      if (editBtn) {
        const id = editBtn.dataset.id;
        const name = editBtn.dataset.name;
        document.getElementById('editId').value = id;
        document.getElementById('editName').value = name;
        const modal = new bootstrap.Modal(document.getElementById('modalEdit'));
        modal.show();
      }

      const delBtn = e.target.closest('.btn-delete');
      if (delBtn) {
        const id = delBtn.dataset.id;
        if (confirm('¿Eliminar esta categoría?')) {
          document.getElementById('delId').value = id;
          document.getElementById('formDelete').submit();
        }
      }
    });
  </script>

</body>
</html>
