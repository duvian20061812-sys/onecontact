<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>inventario</title>
    <link rel="shortcut icon" href="public/identidad-corporativa/inventario.svg" type="image/x-icon">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <!-- ESTILOS EXTERNOS -->
    <!-- Custom fonts for this template-->
    <link href="vistas/recursos/librerias/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

    <!-- ESTILOS PROPIOS -->
    <!-- Custom styles for this template-->
    <link href="vistas/recursos/css/sb-admin-2.min.css" rel="stylesheet">


  
    <!-- Bootstrap core JavaScript-->
    <script src="vistas/recursos/librerias/jquery/jquery.min.js"></script>
    <script src="vistas/recursos/librerias/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <!-- Core plugin JavaScript-->
    <script src="vistas/recursos/librerias/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugins -->
    <script src="vistas/recursos/librerias/datatables/jquery.dataTables.min.js"></script>
    <script src="vistas/recursos/librerias/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level plugins -->
    <script src="vistas/recursos/librerias/chart.js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>  

    <!-- Bootstrap CSS + Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
    /* Transición suave de colores */
  html {
    transition: background-color 0.5s ease, color 0.5s ease;
  }

  body {
    font-family: system-ui, sans-serif;
    transition: background-color 0.5s ease, color 0.5s ease;
  }

  /* Botón de toggle estilo futurista */
  .theme-toggle {
    position: fixed;
    top: 20px;
    right: 20px;
    font-size: 2rem;
    cursor: pointer;
    z-index: 1000;
    transition: transform 0.3s ease, color 0.3s ease, text-shadow 0.3s ease;
  }

  .theme-toggle:hover {
    transform: rotate(20deg) scale(1.3);
    text-shadow: 0 0 15px #00FFFF, 0 0 30px #33FFFF;
  }

  /* Estilos de modo claro */
  [data-bs-theme="light"] body {
    background-color: #f8f9fa;
    color: #212529;
  }

  [data-bs-theme="light"] .bi-chat-dots-fill {
    color: #007AFF;
    text-shadow: 0 0 5px #5AC8FA;
  }

  /* Estilos de modo oscuro futurista */
  [data-bs-theme="dark"] body {
    background-color: #0d1117;
    color: #e6edf3;
  }

  [data-bs-theme="dark"] .bi-chat-dots-fill {
    color: #00AEEF;
    text-shadow: 0 0 10px #00FFFF, 0 0 25px #33FFFF, 0 0 40px #00E6E6;
  }

</style>
</head>

<body id="page-top" class="d-flex justify-content-center align-items-center vh-100"
class="d-flex justify-content-center align-items-center vh-100">
<!-- Botón para alternar tema -->
<i id="theme-toggle" class="bi bi-moon-fill theme-toggle"></i>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Detectar preferencia del sistema
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
  const themeToggle = document.getElementById('theme-toggle');

  // Cargar preferencia guardada o la del sistema
  function getPreferredTheme() {
    return localStorage.getItem('theme')
      || (prefersDark.matches ? 'dark' : 'light');
  }

  // Aplicar el tema
  function setTheme(theme) {
    document.documentElement.setAttribute('data-bs-theme', theme);
    themeToggle.className = theme === 'dark'
      ? 'bi bi-sun-fill theme-toggle text-warning'
      : 'bi bi-moon-fill theme-toggle text-primary';
  }

  // Alternar manualmente
  themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
  });

  // Inicializar
  setTheme(getPreferredTheme());

  // Escuchar cambios del sistema
  prefersDark.addEventListener('change', () => {
    if (!localStorage.getItem('theme')) setTheme(getPreferredTheme());
  });
</script>

    <?php

        if(isset($_SESSION["admin"]) && $_SESSION["admin"] == "ok"){

            include_once  "vistas/administrativas/admin.php";
        
        }else{

            include_once "vistas/publicas/public.php";
        
        }
        
    ?>


    <!-- Scripts propios -->

    <!-- Custom scripts for all pages-->
    <script src="vistas/recursos/js/sb-admin-2.min.js"></script>

    <!-- <script src="vistas/recursos/js/activar-plugins.js"></script> -->
    <script src="vistas/recursos/js/datatable.js"></script>



</body>

</html>