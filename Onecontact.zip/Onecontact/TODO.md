# TODO: Implementar Toggle de Tema Claro/Oscuro en plantilla.php

## Pasos a Completar

- [ ] Editar vistas/modulos/topbar.php: Agregar botón de toggle de tema en la barra de navegación, usando ícono de Bootstrap (bi-sun/bi-moon).
- [ ] Editar vistas/plantilla.php: Agregar JavaScript para manejar el cambio de tema (data-bs-theme), persistencia en localStorage, y actualización del ícono.
- [ ] Editar vistas/plantilla.php: Remover clase "bg-dark" del body para permitir que el tema dinámico funcione.
- [ ] Probar la funcionalidad del toggle en el navegador para asegurar que cambie entre claro y oscuro correctamente.
