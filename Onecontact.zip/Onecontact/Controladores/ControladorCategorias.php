<?php
require_once "Modelos/ModeloCategorias.php";

class ControladorCategorias
{
    /* ============================================================
       Helper SweetAlert (no se modifica)
    ============================================================ */
    private static function swal(string $title, string $text, string $icon, string $redirect = 'categorias'): void
    {
        $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $text  = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
        $redir = htmlspecialchars($redirect, ENT_QUOTES, 'UTF-8');

        echo '<script>
            if (window.Swal) {
              Swal.fire({ title: "'.$title.'", text: "'.$text.'", icon: "'.$icon.'", confirmButtonText: "Entendido"})
                  .then(() => { window.location = "'.$redir.'"; });
            } else {
              alert("'.$title.'\\n'.$text.'");
              window.location = "'.$redir.'";
            }
        </script>';
    }

    /* ============================================================
       Validaciones utilizadas por crear/editar
    ============================================================ */
    private static function validarNombre(?string $nombre): ?string
    {
        if ($nombre === null) return null;
        $nombre = trim($nombre);

        if (mb_strlen($nombre) < 2) return null;

        if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñÜü0-9\s\-\_]+$/u', $nombre)) {
            return null;
        }

        return $nombre;
    }

    private static function filtrarId($valor): ?int
    {
        $id = filter_var($valor, FILTER_VALIDATE_INT);
        return ($id && $id > 0) ? (int)$id : null;
    }

    /* ============================================================
       CREAR CATEGORÍA
       ⚠️ ESTE MÉTODO ES EL QUE SE USA PARA TU NUEVO FRONTEND
    ============================================================ */
    public function crearCategoria(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        // El formulario del nuevo diseño debe enviar:  name="nombre_categoria"
        if (!isset($_POST['nombre_categoria'])) return;

        $nombre = self::validarNombre($_POST['nombre_categoria']);

        if ($nombre === null) {
            self::swal('Nombre inválido', 'No se permiten caracteres especiales o el nombre es demasiado corto.', 'error');
            return;
        }

        $idNuevo = ModeloCategorias::registrarCategoria($nombre);

        if ($idNuevo) {
            self::swal('¡Categoría creada!', 'Tu nueva categoría se guardó correctamente.', 'success');
        } else {
            self::swal('Error al crear', 'Ocurrió un error y no se pudo guardar la categoría.', 'error');
        }
    }

    /* ============================================================
       EDITAR CATEGORÍA (si lo usas)
    ============================================================ */
    public function editarCategoria(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        if (!isset($_POST['id_categoria']) || !isset($_POST['nombre_categoria'])) return;

        $id = self::filtrarId($_POST['id_categoria']);
        if ($id === null) {
            self::swal('Error', 'ID inválido.', 'error');
            return;
        }

        $nombre = self::validarNombre($_POST['nombre_categoria']);
        if ($nombre === null) {
            self::swal('Error', 'Nombre inválido.', 'error');
            return;
        }

        if (ModeloCategorias::actualizarCategoria($id, $nombre)) {
            self::swal('Actualizado', 'La categoría fue actualizada.', 'success');
        } else {
            self::swal('Error', 'No fue posible actualizar.', 'error');
        }
    }

    /* ============================================================
       ELIMINAR CATEGORÍA
    ============================================================ */
    public function eliminarCategoria(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        if (!isset($_POST['id_categoria_eliminar'])) return;

        $id = self::filtrarId($_POST['id_categoria_eliminar']);
        if ($id === null) {
            self::swal('Cuidado', 'ID inválido.', 'error');
            return;
        }

        $ok = ModeloCategorias::eliminarCategoria($id);

        if ($ok) {
            self::swal('Eliminada', 'La categoría fue eliminada correctamente.', 'success');
        } else {
            self::swal('Error', 'No se puede eliminar (quizá tiene productos asociados).', 'error');
        }
    }

    /* ============================================================
       LISTAR CATEGORÍAS (para tablas)
    ============================================================ */
    public static function mostrarCategorias(): array
    {
        return ModeloCategorias::mostrarCategorias() ?? [];
    }
}
