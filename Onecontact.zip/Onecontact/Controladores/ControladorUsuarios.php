<?php
require_once "Modelos/ModeloUsuarios.php";

class ControladorUsuarios {

    /* ============================================================
       MÉTODO: LOGIN DE USUARIO
    ============================================================ */
    public function ingresoUsuario() {

        if (isset($_POST['email']) && isset($_POST['password'])) {

            $email = trim($_POST['email']);
            $password = $_POST['password'];

            // Validar email y contraseña
            if (
                filter_var($email, FILTER_VALIDATE_EMAIL) &&
                preg_match("/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/", $password)
            ) {

                // Buscar usuario en la base de datos
                $usuario = ModeloUsuarios::findByEmail($email);

                if ($usuario) {

                    // Obtener hash almacenado
                    $passBD = $usuario['password_usuario'] ?? null;

                    // Comparar contraseñas
                    if (
                        $passBD &&password_verify($password, $passBD)
                    ) {

                        // Iniciar sesión
                        $_SESSION["admin"] = "ok";
                        $_SESSION["usuario"] = $usuario['nombre_usuario'];
                        $_SESSION["perfil_usuario"] = $usuario['perfil_usuario'] ?? 'usuario';

                        echo '<script>
                            window.location = "dashboard"
                        </script>';

                    } else {
                        echo '<div class="alert alert-danger text-center">Contraseña incorrecta.</div>';
                    }

                } else {
                    echo '<div class="alert alert-warning text-center">No existe un usuario con ese correo.</div>';
                }

            } else {
                echo '<div class="alert alert-danger text-center">Formato de email o contraseña inválido.</div>';
            }
        }
    }


    /* ============================================================
       MÉTODO: REGISTRAR USUARIO (AQUÍ ENCRIPTAMOS)
    ============================================================ */
    public static function registrarUsuario() {

        if (
            isset($_POST["nombre_usuario"]) &&
            isset($_POST["email"]) &&
            isset($_POST["password"])
        ) {
            $nombre = trim($_POST["nombre_usuario"]);
            $email = trim($_POST["email"]);
            $password = $_POST["password"];

            // Validar formato básico
            if (
                filter_var($email, FILTER_VALIDATE_EMAIL) &&
                preg_match("/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/", $password)
            ) {
                // 🔒 Encriptar contraseña
                $passwordHash = password_hash($password, PASSWORD_BCRYPT);

                // Preparar datos
                $datos = [
                    "nombre_usuario" => $nombre,
                    "email" => $email,
                    "password_usuario" => $passwordHash,
                    "perfil_usuario" => "usuario"
                ];

                // Guardar en la BD
                $respuesta = ModeloUsuarios::registrarUsuario($datos);

                if ($respuesta == "ok") {
                    echo '<div class="alert alert-success text-center">Usuario registrado correctamente.</div>';
                } else {
                    echo '<div class="alert alert-danger text-center">Error al registrar el usuario.</div>';
                }

            } else {
                echo '<div class="alert alert-danger text-center">Correo o contraseña no válidos (mínimo 8 caracteres, al menos una letra y un número).</div>';
            }
        }
    }

    public static function mostrarUsuarios(): array
    {
        return ModeloUsuarios::mostrarUsuarios() ?? [];
    }
        

}

 ?> 
    

