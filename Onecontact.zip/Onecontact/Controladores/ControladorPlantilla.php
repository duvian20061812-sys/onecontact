<?php

class ControladorPlantilla{

    public function mostrarPlantilla(){
        include "vistas/plantilla.php";
    }
}